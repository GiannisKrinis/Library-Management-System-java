public enum BookStatus{
  AVAILABLE,
  BORROWED
}